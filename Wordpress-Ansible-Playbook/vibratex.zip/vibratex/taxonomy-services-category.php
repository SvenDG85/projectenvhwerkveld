<?php if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }
/**
 * The Services Template
 */

get_template_part( 'archive-services' );

