<?php if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }
/**
 * Template Name: Testimonials
 */

get_template_part( 'archive-testimonials' );

