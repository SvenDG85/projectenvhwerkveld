<?php if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }
/**
 * Template Name: 404 page
 */

get_template_part( '404' );

