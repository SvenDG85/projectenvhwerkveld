<?php if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }
/**
 * Template Name: Full-Width Page
 */

get_template_part( 'page' );

