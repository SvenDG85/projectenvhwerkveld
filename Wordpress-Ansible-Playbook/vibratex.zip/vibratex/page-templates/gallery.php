<?php if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }
/**
 * Template Name: Gallery
 */

get_template_part( 'archive-gallery' );

